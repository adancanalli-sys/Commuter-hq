import { useState, useEffect, useCallback } from "react";

// ─── persistence ────────────────────────────────────────────────
const KEY = "commuter_v2";
const def = {
  vt: { saldo: 0, recebido: 0, diaRecebimento: 5, historico: [] },
  vr: { saldo: 0, recebido: 0, diaRecebimento: 5, historico: [] },
  bike: { ordens: [], diasBike: 0, diasOnibus: 0 },
  settings: { tarifaOnibus: 4.40, nomeBike: "Minha Bike", notifHora: "07:00", notifAtiva: false },
};

function load() {
  try { return { ...def, ...JSON.parse(localStorage.getItem(KEY) || "{}") }; }
  catch { return def; }
}
function save(d) { localStorage.setItem(KEY, JSON.stringify(d)); }

// ─── helpers ────────────────────────────────────────────────────
const brl = v => Number(v || 0).toLocaleString("pt-BR", { style: "currency", currency: "BRL" });
const hoje = () => new Date().toLocaleDateString("pt-BR");
const uid = () => Math.random().toString(36).slice(2, 9);

function diasParaReceber(dia) {
  const now = new Date();
  let alvo = new Date(now.getFullYear(), now.getMonth(), dia);
  if (alvo <= now) alvo = new Date(now.getFullYear(), now.getMonth() + 1, dia);
  return Math.ceil((alvo - now) / 86400000);
}

function mesAtual() {
  return new Date().toLocaleDateString("pt-BR", { month: "long", year: "numeric" });
}

// ─── notifications ───────────────────────────────────────────────
async function requestNotifPermission() {
  if (!("Notification" in window)) return false;
  if (Notification.permission === "granted") return true;
  const result = await Notification.requestPermission();
  return result === "granted";
}

function scheduleLocalNotif(horaStr) {
  // Cancel previous
  if (window._notifTimeout) clearTimeout(window._notifTimeout);

  const [h, m] = horaStr.split(":").map(Number);
  const now = new Date();
  let alvo = new Date(now.getFullYear(), now.getMonth(), now.getDate(), h, m, 0);
  if (alvo <= now) alvo.setDate(alvo.getDate() + 1);
  const ms = alvo - now;

  window._notifTimeout = setTimeout(() => {
    if (Notification.permission === "granted") {
      new Notification("🚲 Commuter HQ", {
        body: "Não esqueça de registrar se foi de bike ou ônibus hoje!",
        icon: "/icon-192.png",
        tag: "daily",
      });
    }
    // Re-schedule for next day
    scheduleLocalNotif(horaStr);
  }, ms);
}

// ─── sub-components ─────────────────────────────────────────────
function StatCard({ label, value, sub, accent, icon }) {
  return (
    <div style={{
      background: "rgba(255,255,255,0.035)", border: `1px solid ${accent}30`,
      borderRadius: 16, padding: "16px 14px", display: "flex", flexDirection: "column", gap: 4,
      position: "relative", overflow: "hidden",
    }}>
      <div style={{ position: "absolute", top: 10, right: 12, fontSize: 20, opacity: 0.15 }}>{icon}</div>
      <div style={{ fontSize: 10, letterSpacing: 3, color: accent, textTransform: "uppercase", fontWeight: 600 }}>{label}</div>
      <div style={{ fontSize: 20, fontWeight: 800, color: "#fff", lineHeight: 1.1 }}>{value}</div>
      {sub && <div style={{ fontSize: 10, color: "#555", marginTop: 2 }}>{sub}</div>}
    </div>
  );
}

function ProgressRing({ pct, color, size = 80 }) {
  const r = (size - 10) / 2;
  const circ = 2 * Math.PI * r;
  const dash = (pct / 100) * circ;
  return (
    <svg width={size} height={size} style={{ transform: "rotate(-90deg)" }}>
      <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke="rgba(255,255,255,0.07)" strokeWidth={8} />
      <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke={color} strokeWidth={8}
        strokeDasharray={`${dash} ${circ}`} strokeLinecap="round"
        style={{ transition: "stroke-dasharray 0.6s ease" }} />
    </svg>
  );
}

function Input({ label, value, onChange, type = "text", placeholder }) {
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 5 }}>
      <label style={{ fontSize: 10, letterSpacing: 2, color: "#888", textTransform: "uppercase" }}>{label}</label>
      <input type={type} value={value} onChange={onChange} placeholder={placeholder}
        style={{
          background: "rgba(255,255,255,0.05)", border: "1px solid rgba(255,255,255,0.1)",
          borderRadius: 10, color: "#fff", fontSize: 14, padding: "11px 12px",
          fontFamily: "inherit", outline: "none", width: "100%",
        }} />
    </div>
  );
}

function Btn({ children, onClick, color = "#00e5ff", variant = "solid", small, disabled }) {
  return (
    <button onClick={onClick} disabled={disabled} style={{
      padding: small ? "8px 16px" : "11px 22px", borderRadius: 10,
      background: variant === "solid" ? color : "transparent",
      color: variant === "solid" ? "#000" : color,
      border: `1.5px solid ${color}`, fontFamily: "inherit", fontWeight: 700,
      fontSize: small ? 11 : 13, cursor: "pointer", letterSpacing: 1,
      textTransform: "uppercase", opacity: disabled ? 0.4 : 1, transition: "all 0.15s",
      boxShadow: variant === "solid" ? `0 0 14px ${color}44` : "none",
    }}>{children}</button>
  );
}

function Historico({ historico, accent }) {
  const hist = (historico || []).slice(0, 20);
  return (
    <div style={{ background: "rgba(255,255,255,0.03)", border: "1px solid rgba(255,255,255,0.07)", borderRadius: 18, padding: "18px" }}>
      <div style={{ fontSize: 10, letterSpacing: 3, color: "#555", textTransform: "uppercase", marginBottom: 12 }}>Histórico</div>
      {hist.length === 0
        ? <div style={{ color: "#333", fontSize: 13, textAlign: "center", padding: "18px 0" }}>Nenhum registro ainda.</div>
        : <div style={{ display: "flex", flexDirection: "column", gap: 7 }}>
          {hist.map((item, i) => (
            <div key={i} style={{
              display: "flex", alignItems: "center", justifyContent: "space-between",
              background: "rgba(255,255,255,0.03)", borderRadius: 9, padding: "9px 12px",
              borderLeft: `2.5px solid ${item.tipo === "credito" ? "#4ade80" : "#f87171"}`,
            }}>
              <div>
                <div style={{ fontSize: 12, color: "#ccc" }}>{item.desc}</div>
                <div style={{ fontSize: 10, color: "#444" }}>{item.data}</div>
              </div>
              <div style={{ fontWeight: 700, color: item.tipo === "credito" ? "#4ade80" : "#f87171", fontSize: 13 }}>
                {item.tipo === "credito" ? "+" : "-"}{brl(item.valor)}
              </div>
            </div>
          ))}
        </div>
      }
    </div>
  );
}

// ─── PAGES ──────────────────────────────────────────────────────
function PageDashboard({ data, onRegisterBusDay, onRegisterBikeDay }) {
  const { vt, vr, bike, settings } = data;
  const diasVT = diasParaReceber(vt.diaRecebimento || 5);
  const diasVR = diasParaReceber(vr.diaRecebimento || 5);
  const totalDias = (bike.diasBike || 0) + (bike.diasOnibus || 0);
  const pctBike = totalDias > 0 ? Math.round((bike.diasBike / totalDias) * 100) : 0;
  const gastoOnibus = (bike.diasOnibus || 0) * (settings.tarifaOnibus || 4.40) * 2;
  const vtPct = vt.recebido > 0 ? Math.min(100, (vt.saldo / vt.recebido) * 100) : 0;
  const vrPct = vr.recebido > 0 ? Math.min(100, (vr.saldo / vr.recebido) * 100) : 0;
  const economiaOnibus = (bike.diasBike || 0) * (settings.tarifaOnibus || 4.40) * 2;

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 18 }}>
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
        <div>
          <div style={{ fontSize: 10, letterSpacing: 3, color: "#334155", textTransform: "uppercase" }}>painel geral</div>
          <div style={{ fontSize: 18, fontWeight: 800, color: "#fff", textTransform: "capitalize" }}>{mesAtual()}</div>
        </div>
        <div style={{ fontSize: 26 }}>⚡</div>
      </div>

      {/* VT + VR */}
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
        {[
          { label: "Vale Transporte", saldo: vt.saldo, recebido: vt.recebido, pct: vtPct, dias: diasVT, color: "#00e5ff" },
          { label: "Vale Refeição", saldo: vr.saldo, recebido: vr.recebido, pct: vrPct, dias: diasVR, color: "#ff6bdf" },
        ].map(b => (
          <div key={b.label} style={{ background: `${b.color}08`, border: `1px solid ${b.color}28`, borderRadius: 16, padding: "16px 14px" }}>
            <div style={{ fontSize: 9, letterSpacing: 3, color: b.color, textTransform: "uppercase", marginBottom: 3 }}>{b.label}</div>
            <div style={{ fontSize: 22, fontWeight: 900, color: "#fff" }}>{brl(b.saldo)}</div>
            <div style={{ margin: "8px 0 5px", height: 4, borderRadius: 10, background: "rgba(255,255,255,0.07)" }}>
              <div style={{ height: 4, borderRadius: 10, width: `${b.pct}%`, background: b.color, transition: "width 0.6s" }} />
            </div>
            <div style={{ display: "flex", justifyContent: "space-between" }}>
              <span style={{ fontSize: 9, color: "#445" }}>{b.pct.toFixed(0)}% restante</span>
              <span style={{ fontSize: 9, color: b.dias <= 3 ? "#ffd700" : "#445", fontWeight: b.dias <= 3 ? 700 : 400 }}>🕐{b.dias}d</span>
            </div>
          </div>
        ))}
      </div>

      {/* Registro rápido */}
      <div style={{ background: "rgba(255,255,255,0.025)", border: "1px solid rgba(255,255,255,0.07)", borderRadius: 18, padding: "16px" }}>
        <div style={{ fontSize: 10, letterSpacing: 3, color: "#445", textTransform: "uppercase", marginBottom: 12 }}>Registrar dia de hoje</div>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}>
          <button onClick={onRegisterBikeDay} style={{
            padding: "18px 8px", borderRadius: 14, background: "rgba(74,222,128,0.08)",
            border: "1.5px solid #4ade8045", color: "#4ade80", fontFamily: "inherit",
            fontWeight: 700, fontSize: 13, cursor: "pointer", display: "flex",
            flexDirection: "column", alignItems: "center", gap: 5,
          }}>
            <span style={{ fontSize: 28 }}>🚲</span>
            <span>Fui de Bike</span>
          </button>
          <button onClick={onRegisterBusDay} style={{
            padding: "18px 8px", borderRadius: 14, background: "rgba(251,191,36,0.08)",
            border: "1.5px solid #fbbf2445", color: "#fbbf24", fontFamily: "inherit",
            fontWeight: 700, fontSize: 13, cursor: "pointer", display: "flex",
            flexDirection: "column", alignItems: "center", gap: 5,
          }}>
            <span style={{ fontSize: 28 }}>🌧️</span>
            <span>Fui de Ônibus</span>
            <span style={{ fontSize: 9, opacity: 0.6 }}>{brl((settings.tarifaOnibus || 4.40) * 2)} do VT</span>
          </button>
        </div>
      </div>

      {/* Mobilidade */}
      <div style={{ background: "rgba(255,255,255,0.025)", border: "1px solid rgba(255,255,255,0.07)", borderRadius: 18, padding: "18px" }}>
        <div style={{ fontSize: 10, letterSpacing: 3, color: "#445", textTransform: "uppercase", marginBottom: 14 }}>Mobilidade do mês</div>
        <div style={{ display: "flex", alignItems: "center", gap: 18, marginBottom: 14 }}>
          <div style={{ position: "relative" }}>
            <ProgressRing pct={pctBike} color="#4ade80" size={78} />
            <div style={{ position: "absolute", inset: 0, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 12, fontWeight: 800, color: "#4ade80" }}>{pctBike}%</div>
          </div>
          <div style={{ flex: 1, display: "flex", flexDirection: "column", gap: 7 }}>
            <div style={{ display: "flex", justifyContent: "space-between" }}>
              <span style={{ fontSize: 12, color: "#4ade80" }}>🚲 Bike</span>
              <span style={{ fontSize: 12, color: "#fff", fontWeight: 700 }}>{bike.diasBike || 0}d</span>
            </div>
            <div style={{ display: "flex", justifyContent: "space-between" }}>
              <span style={{ fontSize: 12, color: "#fbbf24" }}>🚌 Ônibus</span>
              <span style={{ fontSize: 12, color: "#fff", fontWeight: 700 }}>{bike.diasOnibus || 0}d</span>
            </div>
            <div style={{ display: "flex", justifyContent: "space-between" }}>
              <span style={{ fontSize: 11, color: "#4ade80" }}>💰 Economia</span>
              <span style={{ fontSize: 11, color: "#4ade80", fontWeight: 700 }}>{brl(economiaOnibus)}</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function PageVT({ data, setData }) {
  const [form, setForm] = useState({ saldo: "", recebido: "", diaRecebimento: "", gasto: "" });
  const [msg, setMsg] = useState("");
  const h = f => e => setForm(p => ({ ...p, [f]: e.target.value }));

  function salvar() {
    const vt = data.vt;
    const novoSaldo = form.saldo !== "" ? parseFloat(form.saldo) : vt.saldo;
    const novoRecebido = form.recebido !== "" ? parseFloat(form.recebido) : vt.recebido;
    const novoDia = form.diaRecebimento !== "" ? parseInt(form.diaRecebimento) : vt.diaRecebimento;
    const gasto = parseFloat(form.gasto || 0);
    const hist = [...(vt.historico || [])];
    if (form.recebido) hist.unshift({ id: uid(), tipo: "credito", valor: parseFloat(form.recebido), data: hoje(), desc: "Recebimento VT" });
    if (form.gasto) hist.unshift({ id: uid(), tipo: "debito", valor: gasto, data: hoje(), desc: "Gasto manual" });
    const saldoFinal = form.gasto ? (parseFloat(form.saldo !== "" ? form.saldo : vt.saldo) - gasto) : novoSaldo;
    setData(p => ({ ...p, vt: { saldo: saldoFinal, recebido: novoRecebido, diaRecebimento: novoDia, historico: hist.slice(0, 40) } }));
    setForm({ saldo: "", recebido: "", diaRecebimento: "", gasto: "" });
    setMsg("Salvo!"); setTimeout(() => setMsg(""), 2000);
  }

  const dias = diasParaReceber(data.vt.diaRecebimento || 5);
  const pct = data.vt.recebido > 0 ? Math.min(100, (data.vt.saldo / data.vt.recebido) * 100) : 0;

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
      <div style={{ fontSize: 10, letterSpacing: 3, color: "#00e5ff", textTransform: "uppercase" }}>Vale Transporte</div>
      <div style={{ background: "rgba(0,229,255,0.05)", border: "1px solid #00e5ff28", borderRadius: 18, padding: "22px" }}>
        <div style={{ fontSize: 10, color: "#00e5ff70", letterSpacing: 2, textTransform: "uppercase" }}>Saldo Atual</div>
        <div style={{ fontSize: 40, fontWeight: 900, color: "#fff", letterSpacing: -1 }}>{brl(data.vt.saldo)}</div>
        <div style={{ margin: "12px 0 7px", height: 5, borderRadius: 10, background: "rgba(255,255,255,0.07)" }}>
          <div style={{ height: 5, borderRadius: 10, width: `${pct}%`, background: "linear-gradient(90deg,#00e5ff,#00bcd4)", transition: "width 0.6s", boxShadow: "0 0 10px #00e5ff55" }} />
        </div>
        <div style={{ display: "flex", justifyContent: "space-between" }}>
          <span style={{ fontSize: 10, color: "#445" }}>{pct.toFixed(0)}% do recebido ({brl(data.vt.recebido)})</span>
          <span style={{ fontSize: 10, color: dias <= 3 ? "#ffd700" : "#445", fontWeight: dias <= 3 ? 700 : 400 }}>🕐 {dias} dias</span>
        </div>
      </div>
      <div style={{ background: "rgba(255,255,255,0.025)", border: "1px solid rgba(255,255,255,0.07)", borderRadius: 18, padding: "18px", display: "flex", flexDirection: "column", gap: 12 }}>
        <div style={{ fontSize: 10, letterSpacing: 3, color: "#445", textTransform: "uppercase" }}>Atualizar</div>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}>
          <Input label="Saldo (R$)" value={form.saldo} onChange={h("saldo")} type="number" placeholder={String(data.vt.saldo)} />
          <Input label="Recebido (R$)" value={form.recebido} onChange={h("recebido")} type="number" placeholder="0,00" />
          <Input label="Dia recebimento" value={form.diaRecebimento} onChange={h("diaRecebimento")} type="number" placeholder={String(data.vt.diaRecebimento || 5)} />
          <Input label="Gasto (R$)" value={form.gasto} onChange={h("gasto")} type="number" placeholder="0,00" />
        </div>
        <Btn onClick={salvar} color="#00e5ff">{msg || "Salvar"}</Btn>
      </div>
      <Historico historico={data.vt.historico} accent="#00e5ff" />
    </div>
  );
}

function PageVR({ data, setData }) {
  const [form, setForm] = useState({ saldo: "", recebido: "", diaRecebimento: "", gasto: "" });
  const [msg, setMsg] = useState("");
  const h = f => e => setForm(p => ({ ...p, [f]: e.target.value }));

  function salvar() {
    const vr = data.vr;
    const novoSaldo = form.saldo !== "" ? parseFloat(form.saldo) : vr.saldo;
    const novoRecebido = form.recebido !== "" ? parseFloat(form.recebido) : vr.recebido;
    const novoDia = form.diaRecebimento !== "" ? parseInt(form.diaRecebimento) : vr.diaRecebimento;
    const gasto = parseFloat(form.gasto || 0);
    const hist = [...(vr.historico || [])];
    if (form.recebido) hist.unshift({ id: uid(), tipo: "credito", valor: parseFloat(form.recebido), data: hoje(), desc: "Recebimento VR" });
    if (form.gasto) hist.unshift({ id: uid(), tipo: "debito", valor: gasto, data: hoje(), desc: "Gasto manual" });
    const saldoFinal = form.gasto ? (parseFloat(form.saldo !== "" ? form.saldo : vr.saldo) - gasto) : novoSaldo;
    setData(p => ({ ...p, vr: { saldo: saldoFinal, recebido: novoRecebido, diaRecebimento: novoDia, historico: hist.slice(0, 40) } }));
    setForm({ saldo: "", recebido: "", diaRecebimento: "", gasto: "" });
    setMsg("Salvo!"); setTimeout(() => setMsg(""), 2000);
  }

  const dias = diasParaReceber(data.vr.diaRecebimento || 5);
  const pct = data.vr.recebido > 0 ? Math.min(100, (data.vr.saldo / data.vr.recebido) * 100) : 0;

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
      <div style={{ fontSize: 10, letterSpacing: 3, color: "#ff6bdf", textTransform: "uppercase" }}>Vale Refeição</div>
      <div style={{ background: "rgba(255,107,223,0.05)", border: "1px solid #ff6bdf28", borderRadius: 18, padding: "22px" }}>
        <div style={{ fontSize: 10, color: "#ff6bdf70", letterSpacing: 2, textTransform: "uppercase" }}>Saldo Atual</div>
        <div style={{ fontSize: 40, fontWeight: 900, color: "#fff", letterSpacing: -1 }}>{brl(data.vr.saldo)}</div>
        <div style={{ margin: "12px 0 7px", height: 5, borderRadius: 10, background: "rgba(255,255,255,0.07)" }}>
          <div style={{ height: 5, borderRadius: 10, width: `${pct}%`, background: "linear-gradient(90deg,#ff6bdf,#c084fc)", transition: "width 0.6s", boxShadow: "0 0 10px #ff6bdf55" }} />
        </div>
        <div style={{ display: "flex", justifyContent: "space-between" }}>
          <span style={{ fontSize: 10, color: "#445" }}>{pct.toFixed(0)}% do recebido ({brl(data.vr.recebido)})</span>
          <span style={{ fontSize: 10, color: dias <= 3 ? "#ffd700" : "#445", fontWeight: dias <= 3 ? 700 : 400 }}>🕐 {dias} dias</span>
        </div>
      </div>
      <div style={{ background: "rgba(255,255,255,0.025)", border: "1px solid rgba(255,255,255,0.07)", borderRadius: 18, padding: "18px", display: "flex", flexDirection: "column", gap: 12 }}>
        <div style={{ fontSize: 10, letterSpacing: 3, color: "#445", textTransform: "uppercase" }}>Atualizar</div>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}>
          <Input label="Saldo (R$)" value={form.saldo} onChange={h("saldo")} type="number" placeholder={String(data.vr.saldo)} />
          <Input label="Recebido (R$)" value={form.recebido} onChange={h("recebido")} type="number" placeholder="0,00" />
          <Input label="Dia recebimento" value={form.diaRecebimento} onChange={h("diaRecebimento")} type="number" placeholder={String(data.vr.diaRecebimento || 5)} />
          <Input label="Gasto (R$)" value={form.gasto} onChange={h("gasto")} type="number" placeholder="0,00" />
        </div>
        <Btn onClick={salvar} color="#ff6bdf">{msg || "Salvar"}</Btn>
      </div>
      <Historico historico={data.vr.historico} accent="#ff6bdf" />
    </div>
  );
}

function PageBike({ data, setData }) {
  const [formOS, setFormOS] = useState({ descricao: "", valor: "", data: hoje(), pagoVT: false });
  const [msg, setMsg] = useState("");
  const [tab, setTab] = useState("ordens");
  const ordens = data.bike.ordens || [];
  const totalManutencao = ordens.reduce((s, o) => s + (o.valor || 0), 0);
  const totalVT = ordens.filter(o => o.pagoVT).reduce((s, o) => s + (o.valor || 0), 0);

  function addOrdem() {
    if (!formOS.descricao || !formOS.valor) return;
    const novaOS = { id: uid(), ...formOS, valor: parseFloat(formOS.valor) };
    const novasOrdens = [novaOS, ...ordens];
    let novoVT = data.vt.saldo;
    let histVT = [...(data.vt.historico || [])];
    if (formOS.pagoVT) {
      novoVT -= novaOS.valor;
      histVT.unshift({ id: uid(), tipo: "debito", valor: novaOS.valor, data: hoje(), desc: `🔧 OS: ${novaOS.descricao}` });
    }
    setData(p => ({
      ...p,
      bike: { ...p.bike, ordens: novasOrdens },
      vt: formOS.pagoVT ? { ...p.vt, saldo: novoVT, historico: histVT.slice(0, 40) } : p.vt,
    }));
    setFormOS({ descricao: "", valor: "", data: hoje(), pagoVT: false });
    setMsg("OS adicionada!"); setTimeout(() => setMsg(""), 2000);
  }

  function removeOrdem(id) {
    if (!confirm("Remover esta OS?")) return;
    setData(p => ({ ...p, bike: { ...p.bike, ordens: (p.bike.ordens || []).filter(o => o.id !== id) } }));
  }

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
      <div style={{ fontSize: 10, letterSpacing: 3, color: "#4ade80", textTransform: "uppercase" }}>Bike & Manutenção</div>
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 10 }}>
        <StatCard label="Total gasto" value={brl(totalManutencao)} accent="#4ade80" icon="🔧" />
        <StatCard label="Via VT" value={brl(totalVT)} accent="#00e5ff" icon="💳" />
        <StatCard label="Ordens" value={ordens.length} accent="#fbbf24" icon="📋" />
      </div>
      <div style={{ display: "flex", gap: 8 }}>
        {[["ordens", "📋 Ordens"], ["nova", "➕ Nova OS"]].map(([k, l]) => (
          <button key={k} onClick={() => setTab(k)} style={{
            padding: "8px 14px", borderRadius: 10, fontFamily: "inherit", fontWeight: 600,
            fontSize: 11, cursor: "pointer", letterSpacing: 1, border: "1.5px solid",
            borderColor: tab === k ? "#4ade80" : "rgba(255,255,255,0.08)",
            background: tab === k ? "rgba(74,222,128,0.08)" : "transparent",
            color: tab === k ? "#4ade80" : "#445",
          }}>{l}</button>
        ))}
      </div>

      {tab === "nova" && (
        <div style={{ background: "rgba(255,255,255,0.025)", border: "1px solid rgba(255,255,255,0.07)", borderRadius: 18, padding: "18px", display: "flex", flexDirection: "column", gap: 12 }}>
          <Input label="Descrição do serviço" value={formOS.descricao} onChange={e => setFormOS(p => ({ ...p, descricao: e.target.value }))} placeholder="Ex: Troca de corrente..." />
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}>
            <Input label="Valor (R$)" value={formOS.valor} onChange={e => setFormOS(p => ({ ...p, valor: e.target.value }))} type="number" placeholder="0,00" />
            <Input label="Data" value={formOS.data} onChange={e => setFormOS(p => ({ ...p, data: e.target.value }))} placeholder={hoje()} />
          </div>
          <label style={{
            display: "flex", alignItems: "center", gap: 10, cursor: "pointer",
            padding: "11px 14px", borderRadius: 12, transition: "all 0.2s",
            background: formOS.pagoVT ? "rgba(0,229,255,0.08)" : "rgba(255,255,255,0.03)",
            border: `1.5px solid ${formOS.pagoVT ? "#00e5ff44" : "rgba(255,255,255,0.07)"}`,
          }}>
            <input type="checkbox" checked={formOS.pagoVT} onChange={e => setFormOS(p => ({ ...p, pagoVT: e.target.checked }))}
              style={{ width: 15, height: 15, accentColor: "#00e5ff" }} />
            <div>
              <div style={{ fontSize: 12, color: formOS.pagoVT ? "#00e5ff" : "#667", fontWeight: 600 }}>💳 Pago com VT</div>
              <div style={{ fontSize: 9, color: "#445" }}>Debita automaticamente do saldo</div>
            </div>
          </label>
          <Btn onClick={addOrdem} color="#4ade80">{msg || "Adicionar OS"}</Btn>
        </div>
      )}

      {tab === "ordens" && (
        <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
          {ordens.length === 0
            ? <div style={{ textAlign: "center", color: "#334", padding: "36px 0", fontSize: 13 }}>
              <div style={{ fontSize: 32, marginBottom: 8 }}>🔧</div>
              Nenhuma OS ainda. Adicione a primeira!
            </div>
            : ordens.map(o => (
              <div key={o.id} style={{
                background: "rgba(255,255,255,0.025)", border: "1px solid rgba(255,255,255,0.06)",
                borderRadius: 12, padding: "12px 14px", display: "flex", alignItems: "center", gap: 10,
                borderLeft: `3px solid ${o.pagoVT ? "#00e5ff" : "#4ade80"}`,
              }}>
                <span style={{ fontSize: 20 }}>🔧</span>
                <div style={{ flex: 1 }}>
                  <div style={{ fontSize: 12, color: "#ddd", fontWeight: 600 }}>{o.descricao}</div>
                  <div style={{ fontSize: 10, color: "#445", marginTop: 2 }}>{o.data} {o.pagoVT && <span style={{ color: "#00e5ff", marginLeft: 6 }}>💳 VT</span>}</div>
                </div>
                <div style={{ textAlign: "right" }}>
                  <div style={{ fontSize: 13, fontWeight: 700, color: "#f87171" }}>-{brl(o.valor)}</div>
                  <button onClick={() => removeOrdem(o.id)} style={{ background: "none", border: "none", color: "#334", cursor: "pointer", fontSize: 10, marginTop: 3 }}>remover</button>
                </div>
              </div>
            ))}
        </div>
      )}
    </div>
  );
}

function PageMetricas({ data }) {
  const { vt, vr, bike, settings } = data;
  const ordens = bike.ordens || [];
  const totalDias = (bike.diasBike || 0) + (bike.diasOnibus || 0);
  const pctBike = totalDias > 0 ? Math.round((bike.diasBike / totalDias) * 100) : 0;
  const economiaOnibus = (bike.diasBike || 0) * (settings.tarifaOnibus || 4.40) * 2;
  const gastoManutencao = ordens.reduce((s, o) => s + o.valor, 0);
  const saldoLiquidoBike = economiaOnibus - gastoManutencao;
  const gastoVTOnibus = (bike.diasOnibus || 0) * (settings.tarifaOnibus || 4.40) * 2;
  const gastoVTOS = ordens.filter(o => o.pagoVT).reduce((s, o) => s + o.valor, 0);

  const metrics = [
    { label: "Dias de bike", value: `${bike.diasBike || 0}d`, icon: "🚲", color: "#4ade80", sub: `${pctBike}% das viagens` },
    { label: "Dias de ônibus", value: `${bike.diasOnibus || 0}d`, icon: "🚌", color: "#fbbf24", sub: `${100 - pctBike}% das viagens` },
    { label: "Economia bike", value: brl(economiaOnibus), icon: "💰", color: "#4ade80", sub: "se fosse de ônibus todo dia" },
    { label: "Gasto manutenção", value: brl(gastoManutencao), icon: "🔧", color: "#f87171", sub: `${ordens.length} ordens de serviço` },
    { label: "Saldo líquido bike", value: brl(saldoLiquidoBike), icon: saldoLiquidoBike >= 0 ? "📈" : "📉", color: saldoLiquidoBike >= 0 ? "#4ade80" : "#f87171", sub: "economia − manutenção" },
    { label: "Gasto real ônibus", value: brl(gastoVTOnibus), icon: "🎫", color: "#00e5ff", sub: "debitado do VT" },
    { label: "VT disponível", value: brl(vt.saldo), icon: "💳", color: "#00e5ff", sub: `recebe em ${diasParaReceber(vt.diaRecebimento || 5)} dias` },
    { label: "VR disponível", value: brl(vr.saldo), icon: "🍽️", color: "#ff6bdf", sub: `recebe em ${diasParaReceber(vr.diaRecebimento || 5)} dias` },
  ];

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
      <div style={{ fontSize: 10, letterSpacing: 3, color: "#a78bfa", textTransform: "uppercase" }}>Métricas & Análise</div>
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}>
        {metrics.map((m, i) => (
          <div key={i} style={{
            background: "rgba(255,255,255,0.025)", border: `1px solid ${m.color}20`,
            borderRadius: 14, padding: "14px 12px", borderLeft: `3px solid ${m.color}`,
          }}>
            <div style={{ fontSize: 18, marginBottom: 4 }}>{m.icon}</div>
            <div style={{ fontSize: 9, color: "#445", letterSpacing: 2, textTransform: "uppercase", marginBottom: 2 }}>{m.label}</div>
            <div style={{ fontSize: 17, fontWeight: 800, color: m.color }}>{m.value}</div>
            <div style={{ fontSize: 9, color: "#445", marginTop: 2 }}>{m.sub}</div>
          </div>
        ))}
      </div>
      <div style={{ background: "rgba(167,139,250,0.05)", border: "1px solid #a78bfa25", borderRadius: 16, padding: "18px" }}>
        <div style={{ fontSize: 10, letterSpacing: 3, color: "#a78bfa", textTransform: "uppercase", marginBottom: 12 }}>Resumo VT do mês</div>
        {[
          ["Recebido", brl(vt.recebido), "#00e5ff"],
          ["Gasto ônibus", `- ${brl(gastoVTOnibus)}`, "#fbbf24"],
          ["Gasto manutenção bike", `- ${brl(gastoVTOS)}`, "#f87171"],
          ["Saldo atual", brl(vt.saldo), "#4ade80"],
        ].map(([label, val, color], i, arr) => (
          <div key={i} style={{ display: "flex", justifyContent: "space-between", padding: "8px 0", borderBottom: i < arr.length - 1 ? "1px solid rgba(255,255,255,0.04)" : "none" }}>
            <span style={{ fontSize: 12, color: "#556" }}>{label}</span>
            <span style={{ fontSize: 12, fontWeight: 700, color }}>{val}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

function PageConfig({ data, setData }) {
  const [form, setForm] = useState({
    tarifaOnibus: data.settings?.tarifaOnibus || 4.40,
    nomeBike: data.settings?.nomeBike || "Minha Bike",
    notifHora: data.settings?.notifHora || "07:00",
    notifAtiva: data.settings?.notifAtiva || false,
  });
  const [msg, setMsg] = useState("");
  const [notifStatus, setNotifStatus] = useState(Notification?.permission || "default");

  async function salvar() {
    if (form.notifAtiva) {
      const granted = await requestNotifPermission();
      setNotifStatus(Notification.permission);
      if (granted) scheduleLocalNotif(form.notifHora);
    } else {
      if (window._notifTimeout) clearTimeout(window._notifTimeout);
    }
    setData(p => ({ ...p, settings: { ...p.settings, ...form, tarifaOnibus: parseFloat(form.tarifaOnibus) } }));
    setMsg("Salvo!"); setTimeout(() => setMsg(""), 2000);
  }

  function testarNotif() {
    if (Notification.permission === "granted") {
      new Notification("🚲 Commuter HQ — Teste", { body: "Notificação funcionando! Você irá receber isso todo dia.", icon: "/icon-192.png" });
    }
  }

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
      <div style={{ fontSize: 10, letterSpacing: 3, color: "#94a3b8", textTransform: "uppercase" }}>Configurações</div>

      <div style={{ background: "rgba(255,255,255,0.025)", border: "1px solid rgba(255,255,255,0.07)", borderRadius: 18, padding: "18px", display: "flex", flexDirection: "column", gap: 12 }}>
        <div style={{ fontSize: 10, letterSpacing: 2, color: "#445", textTransform: "uppercase" }}>Geral</div>
        <Input label="Nome da bike" value={form.nomeBike} onChange={e => setForm(p => ({ ...p, nomeBike: e.target.value }))} placeholder="Minha Bike" />
        <Input label="Tarifa do ônibus (R$)" value={form.tarifaOnibus} onChange={e => setForm(p => ({ ...p, tarifaOnibus: e.target.value }))} type="number" placeholder="4.40" />
        <div style={{ fontSize: 9, color: "#334" }}>* Ida + volta = 2x a tarifa, debitado do VT nos dias de ônibus</div>
      </div>

      <div style={{ background: "rgba(255,255,255,0.025)", border: "1px solid rgba(255,255,255,0.07)", borderRadius: 18, padding: "18px", display: "flex", flexDirection: "column", gap: 12 }}>
        <div style={{ fontSize: 10, letterSpacing: 2, color: "#445", textTransform: "uppercase" }}>🔔 Notificação Diária</div>
        <label style={{
          display: "flex", alignItems: "center", gap: 10, cursor: "pointer",
          padding: "11px 14px", borderRadius: 12,
          background: form.notifAtiva ? "rgba(167,139,250,0.08)" : "rgba(255,255,255,0.03)",
          border: `1.5px solid ${form.notifAtiva ? "#a78bfa44" : "rgba(255,255,255,0.07)"}`,
        }}>
          <input type="checkbox" checked={form.notifAtiva} onChange={e => setForm(p => ({ ...p, notifAtiva: e.target.checked }))}
            style={{ width: 15, height: 15, accentColor: "#a78bfa" }} />
          <div>
            <div style={{ fontSize: 12, color: form.notifAtiva ? "#a78bfa" : "#667", fontWeight: 600 }}>Ativar lembrete diário</div>
            <div style={{ fontSize: 9, color: "#445" }}>Status: {notifStatus === "granted" ? "✅ Permitido" : notifStatus === "denied" ? "❌ Bloqueado" : "⏳ Não solicitado"}</div>
          </div>
        </label>
        {form.notifAtiva && (
          <Input label="Horário do lembrete" value={form.notifHora} onChange={e => setForm(p => ({ ...p, notifHora: e.target.value }))} type="time" />
        )}
        {notifStatus === "granted" && (
          <Btn onClick={testarNotif} color="#a78bfa" variant="outline" small>Testar notificação</Btn>
        )}
        {notifStatus === "denied" && (
          <div style={{ fontSize: 10, color: "#f87171", padding: "8px 12px", background: "rgba(248,113,113,0.06)", borderRadius: 8 }}>
            Notificações bloqueadas no navegador. Vá em Configurações do navegador → Notificações e permita este site.
          </div>
        )}
      </div>

      <div style={{ background: "rgba(255,255,255,0.025)", border: "1px solid rgba(255,255,255,0.07)", borderRadius: 18, padding: "18px", display: "flex", flexDirection: "column", gap: 10 }}>
        <div style={{ fontSize: 10, letterSpacing: 2, color: "#445", textTransform: "uppercase" }}>Gerenciar Dados</div>
        <Btn onClick={() => { if (confirm("Resetar contagem de dias do mês?")) setData(p => ({ ...p, bike: { ...p.bike, diasBike: 0, diasOnibus: 0 } })); }} color="#fbbf24" variant="outline">🔄 Resetar contagem mensal</Btn>
        <div style={{ fontSize: 9, color: "#334" }}>Use no início de cada mês para zerar os dias de bike/ônibus</div>
      </div>

      <Btn onClick={salvar} color="#94a3b8">{msg || "Salvar Configurações"}</Btn>
    </div>
  );
}

// ─── MAIN ───────────────────────────────────────────────────────
const PAGES = [
  { id: "dashboard", label: "Painel", icon: "⚡" },
  { id: "vt", label: "VT", icon: "💳" },
  { id: "vr", label: "VR", icon: "🍽️" },
  { id: "bike", label: "Bike", icon: "🚲" },
  { id: "metricas", label: "Métricas", icon: "📊" },
  { id: "config", label: "Config", icon: "⚙️" },
];

const PAGE_COLORS = { dashboard: "#a78bfa", vt: "#00e5ff", vr: "#ff6bdf", bike: "#4ade80", metricas: "#fbbf24", config: "#94a3b8" };

export default function App() {
  const [data, setData] = useState(load);
  const [page, setPage] = useState("dashboard");
  const [toast, setToast] = useState("");

  useEffect(() => { save(data); }, [data]);

  // Re-schedule notification on startup if active
  useEffect(() => {
    if (data.settings?.notifAtiva && Notification?.permission === "granted") {
      scheduleLocalNotif(data.settings.notifHora || "07:00");
    }
  }, []);

  function showToast(msg) { setToast(msg); setTimeout(() => setToast(""), 2500); }

  function registerBusDay() {
    const tarifa = data.settings?.tarifaOnibus || 4.40;
    const custo = tarifa * 2;
    const novoSaldo = Math.max(0, (data.vt.saldo || 0) - custo);
    const hist = [...(data.vt.historico || [])];
    hist.unshift({ id: uid(), tipo: "debito", valor: custo, data: hoje(), desc: "🌧️ Ônibus (ida+volta)" });
    setData(p => ({
      ...p,
      vt: { ...p.vt, saldo: novoSaldo, historico: hist.slice(0, 40) },
      bike: { ...p.bike, diasOnibus: (p.bike.diasOnibus || 0) + 1 },
    }));
    showToast(`🌧️ Ônibus! -${brl(custo)} do VT`);
  }

  function registerBikeDay() {
    setData(p => ({ ...p, bike: { ...p.bike, diasBike: (p.bike.diasBike || 0) + 1 } }));
    showToast("🚲 Dia de bike registrado!");
  }

  const col = PAGE_COLORS[page];

  return (
    <div style={{ minHeight: "100dvh", background: "linear-gradient(160deg,#090e1a 0%,#0d1520 50%,#090e1a 100%)", fontFamily: "'IBM Plex Mono',monospace", color: "#e0e0e0", display: "flex", flexDirection: "column" }}>

      {toast && (
        <div style={{ position: "fixed", top: 18, left: "50%", transform: "translateX(-50%)", background: "#1e293b", border: "1px solid rgba(255,255,255,0.12)", borderRadius: 12, padding: "11px 20px", zIndex: 100, fontSize: 13, color: "#fff", fontFamily: "inherit", boxShadow: "0 8px 32px rgba(0,0,0,0.6)", whiteSpace: "nowrap" }}>{toast}</div>
      )}

      {/* Top bar */}
      <div style={{ position: "sticky", top: 0, zIndex: 10, background: "rgba(9,14,26,0.95)", backdropFilter: "blur(20px)", borderBottom: "1px solid rgba(255,255,255,0.05)", padding: "12px 18px", display: "flex", alignItems: "center", justifyContent: "space-between" }}>
        <div>
          <div style={{ fontSize: 9, color: "#223", letterSpacing: 4, textTransform: "uppercase" }}>Commuter HQ</div>
          <div style={{ fontSize: 14, fontWeight: 800, color: "#fff" }}>
            VT <span style={{ color: "#00e5ff" }}>{brl(data.vt.saldo)}</span>
            <span style={{ color: "#223", margin: "0 7px" }}>·</span>
            VR <span style={{ color: "#ff6bdf" }}>{brl(data.vr.saldo)}</span>
          </div>
        </div>
        <div style={{ fontSize: 9, color: "#334" }}>{hoje()}</div>
      </div>

      {/* Page content */}
      <div style={{ flex: 1, padding: "20px 16px 90px", maxWidth: 640, margin: "0 auto", width: "100%" }}>
        {page === "dashboard" && <PageDashboard data={data} onRegisterBusDay={registerBusDay} onRegisterBikeDay={registerBikeDay} />}
        {page === "vt" && <PageVT data={data} setData={setData} />}
        {page === "vr" && <PageVR data={data} setData={setData} />}
        {page === "bike" && <PageBike data={data} setData={setData} />}
        {page === "metricas" && <PageMetricas data={data} />}
        {page === "config" && <PageConfig data={data} setData={setData} />}
      </div>

      {/* Bottom nav */}
      <div style={{ position: "fixed", bottom: 0, left: 0, right: 0, zIndex: 10, background: "rgba(9,14,26,0.97)", backdropFilter: "blur(24px)", borderTop: "1px solid rgba(255,255,255,0.05)", display: "flex", justifyContent: "space-around", padding: "8px 2px max(12px, env(safe-area-inset-bottom))" }}>
        {PAGES.map(p => {
          const active = page === p.id;
          const c = PAGE_COLORS[p.id];
          return (
            <button key={p.id} onClick={() => setPage(p.id)} style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 2, background: "none", border: "none", cursor: "pointer", padding: "4px 6px", borderRadius: 10, flex: 1 }}>
              <div style={{ fontSize: 19, filter: active ? "none" : "grayscale(1) opacity(0.35)", transition: "filter 0.2s" }}>{p.icon}</div>
              <div style={{ fontSize: 8, letterSpacing: 1, textTransform: "uppercase", color: active ? c : "#2a3a4a", fontWeight: active ? 700 : 400, fontFamily: "inherit", transition: "color 0.2s" }}>{p.label}</div>
              {active && <div style={{ width: 16, height: 2, borderRadius: 2, background: c, boxShadow: `0 0 6px ${c}` }} />}
            </button>
          );
        })}
      </div>
    </div>
  );
}
